import json
from build_vectorstore import STORE_PATH

with open(STORE_PATH, encoding="utf-8") as handle:
    store = json.load(handle)
print(f"strategy={store['strategy']} chunks={len(store['chunks'])}")
for chunk in store["chunks"][:5]:
    print(chunk["metadata"])
