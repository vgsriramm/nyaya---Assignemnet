"""Near-duplicate removal and bounded context assembly."""
import re


def _normalise(text: str) -> str:
    return re.sub(r"\W+", " ", text.lower()).strip()


def assemble_context(results: list[tuple[dict, float]], max_chars: int = 5000):
    kept = []
    seen = []
    for item, relevance in results:
        normalised = _normalise(item["text"])
        if any(normalised in prior or prior in normalised for prior in seen):
            continue
        piece = f"(Source: {item['metadata']['source']})\n{item['text']}"
        if sum(len(existing) for existing in seen) + len(piece) > max_chars:
            break
        seen.append(piece)
        kept.append((item, relevance))
    return "\n\n---\n\n".join(seen), kept
