"""Comparable fixed-size and heading-aware chunking strategies."""
import re


def fixed(text: str, size: int = 650, overlap: int = 80) -> list[str]:
    chunks = []
    step = max(1, size - overlap)
    for start in range(0, len(text), step):
        piece = text[start:start + size].strip()
        if piece:
            chunks.append(piece)
        if start + size >= len(text):
            break
    return chunks


def heading_aware(text: str) -> list[str]:
    pattern = re.compile(r"(?m)^(?:\d+\.\s+|Section\s+\d+:\s*|Clause\s+\d+:\s*).+$")
    headings = list(pattern.finditer(text))
    if not headings:
        return [part.strip() for part in re.split(r"\n\s*\n", text) if part.strip()]
    chunks = []
    for index, match in enumerate(headings):
        end = headings[index + 1].start() if index + 1 < len(headings) else len(text)
        chunk = text[match.start():end].strip()
        if chunk:
            chunks.append(chunk)
    return chunks


STRATEGIES = {"fixed": fixed, "heading_aware": heading_aware}


def chunk_text(text: str, strategy: str) -> list[str]:
    if strategy not in STRATEGIES:
        raise ValueError(f"Unknown chunking strategy: {strategy}")
    return STRATEGIES[strategy](text)
