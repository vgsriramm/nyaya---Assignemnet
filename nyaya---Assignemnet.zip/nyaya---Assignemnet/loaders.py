"""Format-specific loaders that return a common text/metadata shape."""
import csv
import json
import os
import re
import zipfile
from html.parser import HTMLParser
from typing import Any

try:
    import fitz
except ImportError:
    fitz = None
try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None
try:
    from docx import Document as WordDocument
except ImportError:
    WordDocument = None


def _source(path: str) -> str:
    return os.path.basename(path)


def load_pdf(path: str) -> list[dict[str, Any]]:
    result = []
    if fitz is None:
        with open(path, "rb") as handle:
            raw = handle.read().decode("latin-1")
        text = "\n".join(re.findall(r"\((.*?)\)\s*Tj", raw, re.DOTALL))
        text = text.replace(r"\(", "(").replace(r"\)", ")")
        return [{"text": text, "metadata": {"source": _source(path), "page": 1}}] if text else []
    with fitz.open(path) as pdf:
        for page_number, page in enumerate(pdf, 1):
            text = page.get_text().strip()
            if text:
                result.append({"text": text, "metadata": {"source": _source(path), "page": page_number}})
    return result


def load_docx(path: str) -> list[dict[str, Any]]:
    if WordDocument is None:
        with zipfile.ZipFile(path) as archive:
            xml = archive.read("word/document.xml").decode("utf-8")
        text = re.sub(r"<[^>]+>", " ", xml)
        text = re.sub(r"\s+", " ", text).strip()
        return [{"text": text, "metadata": {"source": _source(path), "section": "document"}}]
    document = WordDocument(path)
    text = "\n".join(p.text for p in document.paragraphs if p.text.strip())
    return [{"text": text, "metadata": {"source": _source(path), "section": "document"}}]


def load_html(path: str) -> list[dict[str, Any]]:
    with open(path, encoding="utf-8") as handle:
        html = handle.read()
    if BeautifulSoup is None:
        class TextParser(HTMLParser):
            def __init__(self):
                super().__init__()
                self.parts = []
            def handle_data(self, data):
                if data.strip():
                    self.parts.append(data.strip())
        parser = TextParser()
        parser.feed(html)
        return [{"text": "\n".join(parser.parts), "metadata": {"source": _source(path), "section": "document"}}]
    soup = BeautifulSoup(html, "html.parser")
    result = []
    header = soup.find("p", class_="document-header")
    if header:
        result.append({"text": header.get_text(" ", strip=True),
                       "metadata": {"source": _source(path), "section": "header"}})
    for heading in soup.find_all(["h1", "h2"]):
        title = heading.get_text(" ", strip=True)
        content = []
        for sibling in heading.find_next_siblings():
            if sibling.name in {"h1", "h2"}:
                break
            if sibling.name in {"p", "ul"}:
                content.append(sibling.get_text(" ", strip=True))
        if content:
            result.append({"text": f"{title}\n" + "\n".join(content),
                           "metadata": {"source": _source(path), "section": title}})
    return result


def load_csv(path: str) -> list[dict[str, Any]]:
    result = []
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            result.append({
                "text": "; ".join(f"{key}: {value}" for key, value in row.items()),
                "metadata": {"source": _source(path), "row": row.get("audit_id", "")},
            })
    return result


def load_json(path: str) -> list[dict[str, Any]]:
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    records = data["filings"] if isinstance(data, dict) else data
    return [
        {
            "text": "; ".join(f"{key}: {value}" for key, value in record.items()),
            "metadata": {"source": _source(path), "filing_id": record.get("filing_id", "")},
        }
        for record in records
    ]


LOADERS = {".pdf": load_pdf, ".docx": load_docx, ".html": load_html, ".csv": load_csv, ".json": load_json}


def load_document(path: str) -> list[dict[str, Any]]:
    extension = os.path.splitext(path)[1].lower()
    if extension not in LOADERS:
        raise ValueError(f"No loader registered for {extension}")
    return LOADERS[extension](path)
