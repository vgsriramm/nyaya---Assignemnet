"""Client for the two-terminal demo: start app.py, then run python agent.py."""
import requests

BASE_URL = "http://127.0.0.1:8000/ask"
QUESTIONS = [
    "What is the limitation of liability cap in our standard MSA?",
    "What is the deadline for submitting the quarterly compliance report?",
    "Who do I contact to request an urgent contract review?",
    "Which compliance audit findings are still open?",
    "Which regulatory filings are overdue or due within the next 30 days?",
]


def ask(question: str, pattern: str = "topk") -> dict:
    response = requests.get(BASE_URL, params={"q": question, "pattern": pattern, "k": 4}, timeout=30)
    response.raise_for_status()
    return response.json()


if __name__ == "__main__":
    for number, question in enumerate(QUESTIONS, 1):
        result = ask(question)
        print(f"\nQ{number}: {question}")
        for chunk in result["retrieved_chunks"]:
            print(f"  - {chunk['source']} {chunk['metadata']} score={chunk['relevance_score']}")
        print(f"A{number}: {result['answer']}")
        print(f"Sources: {', '.join(result['sources']) or 'none'}")
    print("\nRetrieval comparison:")
    comparison_question = QUESTIONS[0]
    for pattern in ("topk", "threshold"):
        result = ask(comparison_question, pattern)
        print(f"{pattern}: {[chunk['source'] for chunk in result['retrieved_chunks']]}")
