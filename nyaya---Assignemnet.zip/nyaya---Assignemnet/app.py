"""FastAPI backend for Nyaya's grounded legal/compliance answers."""
import json
import os
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException

from context import assemble_context
from retrieval import normalised_score, retrieve

load_dotenv()
STORE_PATH = os.path.join(os.path.dirname(__file__), "nyaya_store.json")
MIN_CONFIDENCE = 0.04
REFUSAL = "I don't know — none of the ingested documents cover this question confidently enough for me to answer."
SYSTEM_PROMPT = """You are Nyaya, a legal and compliance document assistant. Use only the supplied excerpts.
Every factual claim must end with (Source: <filename>). Never infer legal advice or invent missing facts."""

app = FastAPI(title="Nyaya Legal & Compliance Document Intelligence Pipeline")


def _load_store() -> dict[str, Any]:
    if not os.path.exists(STORE_PATH):
        raise HTTPException(503, "Run build_vectorstore.py before asking questions.")
    with open(STORE_PATH, encoding="utf-8") as handle:
        return json.load(handle)


def _answer(question: str, used: list[tuple[dict, float]], context: str) -> str:
    """Use OpenAI when configured; otherwise provide deterministic cited evidence."""
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        from openai import OpenAI
        response = OpenAI(api_key=api_key).chat.completions.create(
            model=os.getenv("NYAYA_CHAT_MODEL", "gpt-4o-mini"),
            messages=[{"role": "system", "content": SYSTEM_PROMPT},
                      {"role": "user", "content": f"Question: {question}\n\nExcerpts:\n{context}"}],
            temperature=0,
        )
        return response.choices[0].message.content or REFUSAL
    return " ".join(f"{item['text']} (Source: {item['metadata']['source']})" for item, _ in used)


@app.get("/")
def root():
    return {"message": "Nyaya is running. Use /ask?q=...&pattern=topk|threshold&k=3"}


@app.get("/ask")
def ask(q: str, pattern: str = "topk", k: int = 3):
    store = _load_store()
    results = retrieve(store, q, pattern=pattern, k=k)
    confident = [(item, raw) for item, raw in results if normalised_score(raw, q, store) >= MIN_CONFIDENCE]
    if not confident:
        return {"question": q, "pattern": pattern, "retrieved_chunks": [], "answer": REFUSAL, "sources": []}
    context, used = assemble_context(confident)
    retrieved = [
        {"source": item["metadata"]["source"], "metadata": {key: value for key, value in item["metadata"].items() if key != "source"},
         "relevance_score": round(normalised_score(raw, q, store), 4), "text_preview": item["text"][:180]}
        for item, raw in used
    ]
    return {"question": q, "pattern": pattern, "retrieved_chunks": retrieved,
            "answer": _answer(q, used, context), "sources": sorted({item["metadata"]["source"] for item, _ in used})}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
