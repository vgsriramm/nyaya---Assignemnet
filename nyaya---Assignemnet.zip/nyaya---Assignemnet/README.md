# Nyaya — Legal & Compliance Document Intelligence

Nyaya is a fictional NCS Telco+ legal/compliance RAG pipeline. It uses five formats: PDF MSA, DOCX circular, HTML FAQ, CSV audit log, and JSON filing tracker. All documents are fictional.
The filing example uses **2026-10-12** as its fixed reference date; FIL-2026-002 is overdue and FIL-2026-001 is due within 30 days.

## Setup

```powershell
cd nyaya
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python build_vectorstore.py --strategy fixed
python build_vectorstore.py --strategy heading_aware
python inspect_vectorstore.py
```

Run the backend in terminal 1 and the client in terminal 2:

```powershell
python app.py
python agent.py
```

## Comparisons and controls

`fixed` uses overlapping character windows and can split the MSA liability clause across chunks. `heading_aware` keeps Clause 3 (Liability), Clause 4 (Indemnification), and Clause 5 (Governing Law) intact, so it produced the better MSA chunks. The store is deliberately rebuilt with either strategy so the comparison is reproducible.

`topk` always returns the closest records. `threshold` drops weak matches; on an out-of-scope question it returns no evidence and the API refuses before any LLM call. For the liability question, top-k commonly includes the adjacent indemnification clause, while threshold keeps only the liability evidence when the score is below the confidence floor.

PII-safe ingestion redacts the planted email and North American phone number in `03_legal_faq.html`. The build output reports counts without printing the original values.

The API deduplicates near-identical text and caps context at 5,000 characters. If `OPENAI_API_KEY` is configured, answers use the configured chat model with a citation-enforcing system prompt. Without a key, the deterministic fallback still returns retrieved evidence with source citations, making the assignment runnable offline.

## Reflection

1. Heading-aware chunking produced better MSA results because the document is organized as numbered clauses. A fixed window cut the limitation-of-liability sentence near a boundary, while heading-aware indexing kept the cap, exclusions, indemnity relationship, and governing-law clause together. That gives retrieval a complete legal unit rather than a fragment.

2. For the liability question, top-k returned the liability clause plus a nearby indemnification chunk because both share “loss,” “claims,” and “fees.” Threshold retrieval removed the weaker adjacent match when its normalized score fell below the configured floor. Threshold was better for a focused answer; top-k is more useful when a question intentionally spans multiple clauses.

3. Adding 20 contracts would not require changing the loader contract, redaction, chunking, context packing, API, or client. I would add files and likely move the JSON store to Chroma or another managed vector database for concurrent updates, incremental indexing, backups, and metadata filters. The retrieval and citation interfaces could remain stable while the persistence/embedding layer scales.
