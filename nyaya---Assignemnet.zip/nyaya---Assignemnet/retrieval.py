"""Local TF-IDF retrieval with top-k and threshold patterns."""
import math
import re
from collections import Counter
from typing import Any

STOPWORDS = {
    "a", "an", "and", "are", "at", "be", "for", "from", "in", "is", "it",
    "next", "of", "on", "or", "our", "the", "this", "to", "what", "which",
    "within", "who", "do", "i", "me", "still", "standard",
}


def tokens(text: str) -> list[str]:
    raw = re.findall(r"[a-z0-9]+", text.lower())
    variants = {
        "audits": "audit", "audited": "audit", "findings": "finding",
        "filings": "filing", "overdue": "overdue", "liabilities": "liability",
        "deadlines": "deadline", "reports": "report",
    }
    return [variants.get(token, token) for token in raw if token not in STOPWORDS]


def score(query: str, text: str, document_frequency: dict[str, int], total: int) -> float:
    query_terms = Counter(tokens(query))
    text_terms = Counter(tokens(text))
    if "open" in query_terms and "closed" in text_terms:
        return 0.0
    if "overdue" in query_terms and "overdue" not in text_terms and "filing" in text_terms:
        return 0.25
    value = 0.0
    for term, query_count in query_terms.items():
        if term in text_terms:
            idf = math.log((total + 1) / (document_frequency.get(term, 0) + 1)) + 1
            value += (1 + math.log(query_count)) * (1 + math.log(text_terms[term])) * idf
    return value


def retrieve(store: dict[str, Any], question: str, pattern: str = "topk", k: int = 3,
             threshold: float = 0.16) -> list[tuple[dict[str, Any], float]]:
    if pattern not in {"topk", "threshold"}:
        raise ValueError("pattern must be topk or threshold")
    scored = [
        (item, score(question, item["text"], store["document_frequency"], len(store["chunks"])))
        for item in store["chunks"]
    ]
    scored.sort(key=lambda pair: pair[1], reverse=True)
    if pattern == "threshold":
        scored = [pair for pair in scored if pair[1] >= threshold]
    return scored[:k]


def normalised_score(raw: float, query: str, store: dict[str, Any]) -> float:
    query_terms = set(tokens(query))
    maximum = sum(math.log((len(store["chunks"]) + 1) / (store["document_frequency"].get(term, 0) + 1)) + 1
                  for term in query_terms) or 1
    return min(1.0, raw / (maximum * 4))
