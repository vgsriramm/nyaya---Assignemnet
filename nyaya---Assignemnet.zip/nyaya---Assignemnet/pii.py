"""PII detection and redaction before text is indexed."""
import re

PATTERNS = {
    "EMAIL": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    "PHONE": re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}(?!\d)"),
}


def redact_pii(text: str) -> tuple[str, dict[str, int]]:
    counts: dict[str, int] = {}
    redacted = text
    for label, pattern in PATTERNS.items():
        matches = pattern.findall(redacted)
        if matches:
            counts[label] = len(matches)
            redacted = pattern.sub(f"[REDACTED_{label}]", redacted)
    return redacted, counts
