"""Build a small persistent local vector store: python build_vectorstore.py --strategy fixed."""
import argparse
import json
import os
import re
from collections import Counter

from chunking import chunk_text, STRATEGIES
from loaders import load_document
from pii import redact_pii

DOCUMENT_DIR = os.path.join(os.path.dirname(__file__), "documents")
STORE_PATH = os.path.join(os.path.dirname(__file__), "nyaya_store.json")


def build(strategy: str) -> None:
    chunks = []
    pii_totals = Counter()
    for name in sorted(os.listdir(DOCUMENT_DIR)):
        path = os.path.join(DOCUMENT_DIR, name)
        if not os.path.isfile(path):
            continue
        units = load_document(path)
        for unit in units:
            clean, counts = redact_pii(unit["text"])
            pii_totals.update(counts)
            for index, text in enumerate(chunk_text(clean, strategy)):
                metadata = dict(unit["metadata"])
                metadata.update({"chunk_index": index, "chunking_strategy": strategy})
                chunks.append({"text": text, "metadata": metadata})
    document_frequency = Counter()
    for item in chunks:
        document_frequency.update(set(re.findall(r"[a-z0-9]+", item["text"].lower())))
    store = {"strategy": strategy, "chunks": chunks, "document_frequency": dict(document_frequency)}
    with open(STORE_PATH, "w", encoding="utf-8") as handle:
        json.dump(store, handle, indent=2)
    print(f"Built {len(chunks)} chunks with {strategy} strategy.")
    print(f"PII redacted during ingestion: {dict(pii_totals) or 'none'}")
    print(f"Store written to {STORE_PATH}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--strategy", choices=STRATEGIES, default="heading_aware")
    build(parser.parse_args().strategy)
